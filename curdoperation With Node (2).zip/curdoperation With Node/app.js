const express = require("express");
const mongoose = require("mongoose");
const app = express();

// Connect to MongoDB Atlas
mongoose.connect("mongodb+srv://renilbhai1983:book123@cluster0.2t4vebu.mongodb.net/mobilesDB?retryWrites=true&w=majority", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(() => {
    console.log("Connected to MongoDB Atlas");
    insertInitialProducts();  // Insert initial products if they don't exist
}).catch((error) => {
    console.error("Error connecting to MongoDB Atlas", error);
});

const mobileSchema = new mongoose.Schema({
    id: Number,
    name: String,
    price: String,
    img: String,
    day: String,
    ins: String,
    total: String,
});

const Mobile = mongoose.model("Mobile", mobileSchema);

app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: true }));

// Insert initial products if they don't already exist
async function insertInitialProducts() {
    const initialProducts = [
        {
            id: 1,
            name: "Iphone 15",
            price: "74,000",
            img: "https://www.poojaratele.com/media/catalog/product/cache/4660d2675ce46398cb4d17672c98889f/i/1/i1_3.jpg",
            day: "5",
            ins: "20",
            total: "100"
        },
        {
            id: 2,
            name: "Samsung A15",
            price: "19,000",
            img: "https://www.poojaratele.com/media/catalog/product/cache/2ee311823438cb633f5cdd390f643aa6/a/1/a1_1_1.jpg",
            day: "4",
            ins: "20",
            total: "80" 
        }
    ];

    for (const product of initialProducts) {
        const exists = await Mobile.findOne({ id: product.id });
        if (!exists) {
            await new Mobile(product).save();
        }
    }
}

// Render the home page with all mobile records
app.get("/", async (req, res) => {
    try {
        const mobiles = await Mobile.find();
        res.render("index", { Mobile: mobiles });
    } catch (error) {
        console.error("Error fetching mobiles", error);
        res.status(500).send("Error fetching mobiles");
    }
});

// Insert a new mobile record
app.post("/insert", async (req, res) => {
    const { id, name, price, img, day, ins, total } = req.body;

    const newMobile = new Mobile({
        id: parseInt(id, 10), // Ensure ID is an integer
        name,
        price,
        img,
        day,
        ins,
        total
    });

    try {
        await newMobile.save();
        res.redirect("/");
    } catch (error) {
        console.error("Error inserting mobile", error);
        res.status(500).send("Error inserting mobile");
    }
});

// Delete a mobile record by ID
app.post("/delete/:id", async (req, res) => {
    const idToDelete = parseInt(req.params.id, 10); // Ensure ID is an integer

    try {
        await Mobile.deleteOne({ id: idToDelete });
        res.redirect("/");
    } catch (error) {
        console.error("Error deleting mobile", error);
        res.status(500).send("Error deleting mobile");
    }
});

// Edit a mobile record by ID
app.post("/edit/:id", async (req, res) => {
    const idToEdit = parseInt(req.params.id, 10); // Ensure ID is an integer
    const { name, price, img, day, ins, total } = req.body;

    try {
        await Mobile.updateOne(
            { id: idToEdit },
            { $set: { name, price, img, day, ins, total } }
        );
        res.redirect("/");
    } catch (error) {
        console.error("Error editing mobile", error);
        res.status(500).send("Error editing mobile");
    }
});

// Start the server
app.listen(7107, () => {
    console.log("Server started on port 7107");
});
